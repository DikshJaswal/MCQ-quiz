from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.user_login, name='login'),
    path('signup/', views.signup, name='signup'),
    path('logout/', views.custom_logout, name='logout'),
    path('subject-selection/', views.subject_selection, name='subject-selection'),
    path('unit-selection/', views.unit_selection, name='unit-selection'),
    path('test/', views.test, name='test'),  # Add this line
    path('add-question/', views.add_question, name='add-question'),
    path('manage-questions/', views.manage_questions, name='manage-questions'),
    path('edit-question/<int:question_id>/', views.edit_question, name='edit-question'),
    path('delete-question/<int:question_id>/', views.delete_question, name='delete-question'),
]