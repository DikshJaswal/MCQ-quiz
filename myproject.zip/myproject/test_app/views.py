from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from .forms import CustomSignUpForm
from django.contrib.auth.decorators import login_required

@login_required
def home(request):
    return render(request, 'test_app/home.html')

def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
        else:
            return render(request, 'test_app/login.html', {'form': form})
    else:
        form = AuthenticationForm()
    return render(request, 'test_app/login.html', {'form': form})

def signup(request):
    if request.method == 'POST':
        form = CustomSignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'test_app/signup.html', {'form': form})
    else:
        form = CustomSignUpForm()
    return render(request, 'test_app/signup.html', {'form': form})

def custom_logout(request):
    logout(request)
    return redirect('login')

@login_required
def subject_selection(request):
    return render(request, 'test_app/subject_selection.html')

@login_required
def unit_selection(request):
    return render(request, 'test_app/unit_selection.html')

@login_required
def test(request):
    return render(request, 'test_app/test.html')


#for creating views for managing questions
from django.shortcuts import render, redirect, get_object_or_404
from .forms import QuestionForm
from .models import Question

def add_question(request):
    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('manage-questions')
    else:
        form = QuestionForm()
    return render(request, 'test_app/add_question.html', {'form': form})

def manage_questions(request):
    questions = Question.objects.all()
    return render(request, 'test_app/manage_questions.html', {'questions': questions})

def edit_question(request, question_id):
    question = get_object_or_404(Question, id=question_id)
    if request.method == 'POST':
        form = QuestionForm(request.POST, instance=question)
        if form.is_valid():
            form.save()
            return redirect('manage-questions')
    else:
        form = QuestionForm(instance=question)
    return render(request, 'test_app/edit_question.html', {'form': form})

def delete_question(request, question_id):
    question = get_object_or_404(Question, id=question_id)
    question.delete()
    return redirect('manage-questions')


#for set up the test page
import json
import random
from django.shortcuts import render
from django.conf import settings

def test(request):
    # Load questions from the JSON file
    with open(f"{settings.BASE_DIR}/static/test_app/questions.json", "r") as file:
        questions = json.load(file)
    
    # Filter questions based on the selected subject and unit
    selected_subject = request.session.get('selected_subject')
    selected_unit = request.session.get('selected_unit')
    filtered_questions = [q for q in questions if q['subject'] == selected_subject and q['unit'] == selected_unit]
    
    # Select 10 random questions
    random_questions = random.sample(filtered_questions, min(10, len(filtered_questions)))
    
    # Store the selected questions in the session
    request.session['test_questions'] = random_questions
    request.session['current_question_index'] = 0
    request.session['user_answers'] = []
    
    return render(request, 'test_app/test.html', {'question': random_questions[0]})

#to add result page
def results(request):
    score = request.session.get('score', 0)
    test_questions = request.session.get('test_questions', [])
    user_answers = request.session.get('user_answers', [])
    correct_answers = [q['correct_answer'] for q in test_questions]
    
    # Prepare results data
    results_data = []
    for i, (question, user_answer, correct_answer) in enumerate(zip(test_questions, user_answers, correct_answers)):
        results_data.append({
            'question': question['question_text'],
            'user_answer': user_answer,
            'correct_answer': correct_answer,
            'is_correct': user_answer == correct_answer
        })
    
    return render(request, 'test_app/results.html', {'score': score, 'results_data': results_data})