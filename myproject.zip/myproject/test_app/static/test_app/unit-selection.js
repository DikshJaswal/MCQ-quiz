const units = {
    "Mathematics I": ["Unit 1: Basic Algebra", "Unit 2: Calculus", "Unit 3: Geometry"],
    "Physics I": ["Unit 1: Mechanics", "Unit 2: Thermodynamics", "Unit 3: Optics"],
    "Environmental Science": ["Unit 1: Ecosystems", "Unit 2: Pollution", "Unit 3: Climate Change"],
    "Communication": ["Unit 1: Verbal Communication", "Unit 2: Non-Verbal Communication", "Unit 3: Writing Skills"],
    "Basic Electrical Engineering": ["Unit 1: Circuits", "Unit 2: Magnetism", "Unit 3: AC/DC"],
    "Mathematics II": ["Unit 1: Linear Algebra", "Unit 2: Differential Equations", "Unit 3: Vector Calculus"],
    "Chemistry": ["Unit 1: Organic Chemistry", "Unit 2: Inorganic Chemistry", "Unit 3: Physical Chemistry"],
    "C++": ["Unit 1: Basics", "Unit 2: Object-Oriented Programming", "Unit 3: Data Structures"],
    "Basic Electronics Engineering": ["Unit 1: Diodes", "Unit 2: Transistors", "Unit 3: Amplifiers"],
    "UHV": ["Unit 1: Human Values", "Unit 2: Professional Ethics", "Unit 3: Social Responsibility"],
    "DSA": ["Unit 1: Arrays", "Unit 2: Linked Lists", "Unit 3: Trees"],
    "Python": ["Unit 1: Basics", "Unit 2: Data Structures", "Unit 3: Web Development"],
    "Digital System Design": ["Unit 1: Logic Gates", "Unit 2: Flip-Flops", "Unit 3: Sequential Circuits"],
    "Probability and Statistics": ["Unit 1: Probability", "Unit 2: Statistics", "Unit 3: Distributions"],
    "IKS": ["Unit 1: Ancient Knowledge", "Unit 2: Traditional Practices", "Unit 3: Modern Applications"],
    "COA": ["Unit 1: Architecture", "Unit 2: Memory", "Unit 3: Input/Output"],
    "Engineering Economics": ["Unit 1: Cost Analysis", "Unit 2: Financial Planning", "Unit 3: Project Evaluation"],
};

const selectedSubjects = JSON.parse(localStorage.getItem('selectedSubjects')) || [];
const subjectInfo = document.getElementById('subject-info');
const unitList = document.getElementById('unit-list');

if (selectedSubjects.length > 0) {
    subjectInfo.innerHTML = `<h3>Select Unit for the Selected Subject</h3>`;
    unitList.innerHTML = '';
    const currentSubject = selectedSubjects[selectedSubjects.length - 1];
    const subjectDiv = document.createElement('div');
    subjectDiv.classList.add('subject-unit-container');
    const label = document.createElement('label');
    label.textContent = `Select Unit for ${currentSubject}:`;
    subjectDiv.appendChild(label);
    const unitSelect = document.createElement('select');
    unitSelect.setAttribute('id', `unit-${currentSubject}`);
    const defaultOption = document.createElement('option');
    defaultOption.textContent = "Select a Unit";
    unitSelect.appendChild(defaultOption);
    const subjectUnits = units[currentSubject] || [];
    subjectUnits.forEach(unit => {
        const option = document.createElement('option');
        option.textContent = unit;
        unitSelect.appendChild(option);
    });
    subjectDiv.appendChild(unitSelect);
    unitList.appendChild(subjectDiv);
} else {
    subjectInfo.textContent = "No subjects selected. Please go back and select subjects.";
}

document.getElementById('unit-selection-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const selectedUnits = {};
    if (selectedSubjects.length > 0) {
        const currentSubject = selectedSubjects[selectedSubjects.length - 1];
        const unitSelect = document.getElementById(`unit-${currentSubject}`);
        selectedUnits[currentSubject] = unitSelect.value;
    }
    localStorage.setItem('selectedUnits', JSON.stringify(selectedUnits));
    // Get the test URL from the form's data attribute
    const testUrl = event.target.getAttribute('data-test-url');
    window.location.href = testUrl;
});