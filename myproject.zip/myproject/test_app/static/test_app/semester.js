document.querySelectorAll('.semester-btn').forEach(button => {
    button.addEventListener('click', function() {
        const selectedSemester = button.getAttribute('data-semester');
        localStorage.setItem('semester', selectedSemester);
    });
});

document.getElementById('semester-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const selectedSemester = localStorage.getItem('semester');
    if (selectedSemester) {
        // Get the subject-selection URL from the form's data attribute
        const subjectSelectionUrl = event.target.getAttribute('data-subject-selection-url');
        window.location.href = subjectSelectionUrl;
    } else {
        alert('Please select a semester first!');
    }
});