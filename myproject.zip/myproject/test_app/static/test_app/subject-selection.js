const subjects = {
    1: ["Mathematics I", "Physics I", "Environmental Science", "Communication", "Basic Electrical Engineering"],
    2: ["Mathematics II", "Chemistry", "C++", "Basic Electronics Engineering", "UHV"],
    3: ["DSA", "Python", "Digital System Design", "Probability and Statistics", "IKS", "COA", "Engineering Economics"],
    // Add other semesters here...
};

const selectedSemester = localStorage.getItem('semester');
const subjectList = document.getElementById('subject-list');
const semesterInfo = document.getElementById('semester-info');

function displaySubjects() {
    if (selectedSemester) {
        semesterInfo.innerHTML = `<h3>Semester ${selectedSemester}</h3>`;
        const selectedSubjects = subjects[selectedSemester];
        if (selectedSubjects && selectedSubjects.length > 0) {
            selectedSubjects.forEach(subject => {
                const button = document.createElement('button');
                button.textContent = subject;
                button.classList.add('subject-button');
                button.addEventListener('click', () => toggleSelection(button, subject));
                subjectList.appendChild(button);
            });
        } else {
            subjectList.textContent = 'No subjects found for this semester.';
        }
    } else {
        semesterInfo.textContent = 'No semester selected. Please go back and select a semester.';
    }
}

function toggleSelection(button, subject) {
    button.classList.toggle('selected');
    let selectedSubjects = JSON.parse(localStorage.getItem('selectedSubjects')) || [];

    if (button.classList.contains('selected')) {
        if (!selectedSubjects.includes(subject)) {
            selectedSubjects.push(subject);
        }
    } else {
        const index = selectedSubjects.indexOf(subject);
        if (index > -1) {
            selectedSubjects.splice(index, 1);
        }
    }

    localStorage.setItem('selectedSubjects', JSON.stringify(selectedSubjects));
}

displaySubjects();

document.getElementById('subject-selection-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const selectedSubjects = JSON.parse(localStorage.getItem('selectedSubjects')) || [];
    if (selectedSubjects.length > 0) {
        // Get the unit-selection URL from the form's data attribute
        const unitSelectionUrl = event.target.getAttribute('data-unit-selection-url');
        window.location.href = unitSelectionUrl;
    } else {
        alert('Please select at least one subject!');
    }
});