from django.conf import settings
from django.db import models
from django.utils import timezone


# To this:
User = settings.AUTH_USER_MODEL
class Semester(models.Model):
    number = models.PositiveSmallIntegerField(unique=True)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)

    def __str__(self):
        return f"Semester {self.number}: {self.name}"

class Subject(models.Model):
    semester = models.ForeignKey(Semester, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)

    class Meta:
        unique_together = ('semester', 'name')

    def __str__(self):
        return f"{self.name} (Semester {self.semester.number})"

class Topic(models.Model):
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name="topics")  # ✅ Use related_name
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)

    class Meta:
        unique_together = ('subject', 'name')

    def __str__(self):
        return f"{self.name} ({self.subject.name})"



class QuizQuestion(models.Model):
    topic = models.ForeignKey(Topic, on_delete=models.CASCADE)
    question_text = models.TextField()
    option1 = models.CharField(max_length=200)
    option2 = models.CharField(max_length=200)
    option3 = models.CharField(max_length=200)
    option4 = models.CharField(max_length=200)
    correct_option = models.PositiveSmallIntegerField(choices=[(1, 'Option 1'), (2, 'Option 2'), (3, 'Option 3'), (4, 'Option 4')])
    explanation = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.question_text[:100]

class QuizAttempt(models.Model):
    # Change this:
    # user = models.ForeignKey(User, on_delete=models.CASCADE)
    
    # To this:
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    topic = models.ForeignKey(Topic, on_delete=models.CASCADE)
    score = models.PositiveSmallIntegerField()
    total_questions = models.PositiveSmallIntegerField()
    completed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-completed_at']

    def percentage(self):
        return round((self.score / self.total_questions) * 100)
    
class Question(models.Model):  # Make sure this exists
    topic = models.ForeignKey(Topic, on_delete=models.CASCADE)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

def save_score(user, score, total_questions):
    percentage = (score / total_questions) * 100

    # Feedback logic
    if percentage >= 80:
        feedback = "Excellent! You have a great understanding."
    elif percentage >= 60:
        feedback = "Good job! Some areas need improvement."
    elif percentage >= 40:
        feedback = "Fair. Try to review the concepts again."
    else:
        feedback = "Needs improvement. Focus on weak areas."

    # Save to database (if needed)
    QuizAttempt.objects.create(
        user=user,
        score=score,
        total_questions=total_questions
    )
    
    return feedback  # Return for immediate display
