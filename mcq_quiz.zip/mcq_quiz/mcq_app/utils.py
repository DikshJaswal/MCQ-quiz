import re

def parse_question(text):
    """Parses a question string into structured data."""
    match = re.search(r"Question:\s*(.*?)\nA\)\s*(.*?)\nB\)\s*(.*?)\nC\)\s*(.*?)\nD\)\s*(.*?)\nCorrect Answer:\s*(\w)\nExplanation:\s*(.*)", text, re.DOTALL)
    if match:
        return {
            "question": match.group(1),
            "options": [match.group(2), match.group(3), match.group(4), match.group(5)],
            "correct_option": match.group(6),
            "explanation": match.group(7),
        }
    return None

import google.generativeai as genai
import json
import random


def generate_questions(topic_name, subject_name):
    prompt = f"""
    Generate 15 multiple-choice questions about {topic_name} in {subject_name}.
    Include questions at three difficulty levels:
    1. GATE examination level (5 questions)
    2. University examination level (5 questions)
    3. Technical interview level (5 questions)
    
    Each question should have four options, with one correct answer.
    Mark difficult questions with '(GATE)' and challenging ones with '(Interview)' in the question text.
    
    Format the response as a JSON array:
    [
        {{
            "question": "What is 2+2? (GATE)",
            "options": ["3", "4", "5", "6"],
            "answer": "4",
            "difficulty": "GATE"
        }},
        {{
            "question": "Explain the concept of... (Interview)",
            "options": ["Option1", "Option2", "Option3", "Option4"],
            "answer": "Option3",
            "difficulty": "Interview"
        }},
        ...
    ]
    """
    try:
        model = genai.GenerativeModel("gemini-1.5-pro")
        response = model.generate_content(prompt)

        if not response or not hasattr(response, 'text') or not response.text.strip():
            print("❌ Gemini API returned an empty response!")
            return []

        # Clean the response text
        response_text = response.text.strip()
        for marker in ["```json", "```"]:
            if response_text.startswith(marker):
                response_text = response_text[len(marker):].strip()
            if response_text.endswith(marker):
                response_text = response_text[:-len(marker)].strip()
        
        # Parse the response
        try:
            questions = json.loads(response_text)
            if len(questions) < 15:
                print(f"⚠️ Got only {len(questions)} questions, expected 15")
            
            # Randomize the order of questions
            random.shuffle(questions)
            
            return questions
        except json.JSONDecodeError as e:
            print(f"❌ JSON parse error: {e}\nResponse text was:\n{response_text}")
            return []
        
    except Exception as e:
        print(f"❌ Error fetching questions: {e}")
        return []