
import logging

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.urls import reverse

import google.generativeai as genai
import matplotlib
matplotlib.use('Agg')  # Must be before pyplot import
import matplotlib.pyplot as plt
from io import BytesIO
import base64
import json 
import time

from .models import Semester, Subject, Topic, QuizQuestion, QuizAttempt, save_score
from .utils import generate_questions

import os
genai.configure(api_key='AIzaSyCB77gRvvBoT05NFWRRRBs2jMNGuyk_dp8')
model = genai.GenerativeModel("gemini-1.5-pro")

logger = logging.getLogger(__name__)


# ---------- Basic Views ----------

def home(request):
    return render(request, 'mcq_app/home.html')


@login_required
def semester_list(request):
    semesters = Semester.objects.all().order_by('number')
    return render(request, 'mcq_app/semester_list.html', {'semesters': semesters})


@login_required
def semester_subjects(request, semester_id):
    semester = get_object_or_404(Semester, pk=semester_id)
    subjects = Subject.objects.filter(semester=semester)
    return render(request, 'mcq_app/semester_subjects.html', {
        'semester_id': semester_id,
        'subjects': subjects
    })


@login_required
def subject_topics(request, semester_id, subject_id):
    subject = get_object_or_404(Subject, pk=subject_id, semester=semester_id)
    topics = Topic.objects.filter(subject=subject)
    return render(request, 'mcq_app/subject_topics.html', {
        'semester_id': semester_id,
        'subject_id': subject_id,
        'subject': subject,
        'topics': topics
    })


# ---------- Quiz Generation ----------

@login_required
def generate_quiz(request, semester_id, subject_id, topic_id):
    topic = get_object_or_404(Topic, pk=topic_id, subject_id=subject_id)

    if request.method == 'POST':
        questions = generate_questions(topic.name, topic.subject.name)
        if questions:
            request.session['generated_questions'] = questions
            request.session['quiz_answers'] = {}  # reset answers
            request.session.modified = True
            messages.success(request, "Quiz questions generated successfully!")
            return redirect('mcq_app:quiz_start', topic_id=topic.id)
        else:
            messages.error(request, "Failed to generate quiz questions. Please try again.")

    return render(request, 'mcq_app/generate.html', {'topic': topic})


# ---------- Quiz Flow ----------

@login_required
def quiz_start(request, topic_id):
    topic = get_object_or_404(Topic, id=topic_id)
    questions = request.session.get('generated_questions', [])

    if not questions:
        messages.error(request, "No questions available. Please generate quiz first.")
        return redirect('mcq_app:generate_quiz', semester_id=topic.subject.semester.id, subject_id=topic.subject.id, topic_id=topic_id)

    if request.method == "POST":
        answers = {str(i): request.POST.get(f'answer_{i}', None) for i in range(1, len(questions) + 1)}
        request.session['quiz_answers'] = answers
        request.session.modified = True
        return redirect('mcq_app:quiz_results', topic_id=topic_id)

    return render(request, 'mcq_app/quiz_start.html', {
        'topic': topic,
        'questions': questions,
        'question': questions[0],
        'question_num': 1,
        'total': len(questions),
        'progress_percentage': 0,
    })


@login_required
def quiz_question(request, topic_id, question_num):
    questions = request.session.get('generated_questions', [])
    total = len(questions)

    if not questions or question_num < 1 or question_num > total:
        return redirect('mcq_app:quiz_start', topic_id=topic_id)

    question = questions[question_num - 1]
    selected = request.session.get('quiz_answers', {}).get(str(question_num))

    return render(request, 'mcq_app/quiz_question.html', {
        'topic': get_object_or_404(Topic, id=topic_id),
        'question': question,
        'question_num': question_num,
        'total': total,
        'progress_percentage': (question_num / total) * 100,
        'selected_option': selected
    })


@login_required
def save_answer(request):
    if request.method == 'POST':
        question_id = request.POST.get('question_id')
        selected_option = request.POST.get('answer')

        request.session.setdefault('quiz_answers', {})
        request.session['quiz_answers'][question_id] = selected_option
        request.session.modified = True

        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'error'}, status=400)


# ---------- Quiz Results ----------

def generate_performance_graph(past_results):
    """Generate base64 encoded performance graph"""
    if not past_results:
        return None
    
    try:
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Prepare data
        attempts = [f"Attempt {i+1}" for i in range(len(past_results))]
        correct = [res[0] for res in past_results]
        wrong = [res[1] for res in past_results]
        
        # Plotting
        bar_width = 0.35
        r1 = range(len(correct))
        r2 = [x + bar_width for x in r1]
        
        ax.bar(r1, correct, color='#4CAF50', width=bar_width, label='Correct')
        ax.bar(r2, wrong, color='#F44336', width=bar_width, label='Wrong')
        
        # Formatting
        ax.set_xlabel('Quiz Attempts')
        ax.set_ylabel('Number of Questions')
        ax.set_title('Performance History')
        ax.set_xticks([r + bar_width/2 for r in range(len(correct))], attempts)
        ax.legend()
        
        # Save to buffer
        buffer = BytesIO()
        plt.tight_layout()
        plt.savefig(buffer, format='png', dpi=100)
        plt.close()
        return base64.b64encode(buffer.getvalue()).decode('utf-8')
        
    except Exception as e:
        logger.error(f"Graph generation error: {e}")
        return None

@login_required
def quiz_results(request, topic_id):
    """Display quiz results with guaranteed explanations"""
    try:
        topic = get_object_or_404(Topic, id=topic_id)
        questions = request.session.get('generated_questions', [])
        user_answers = request.session.get('quiz_answers', {})

        if not questions or not user_answers:
            messages.error(request, "Quiz data missing.")
            return redirect('mcq_app:generate_quiz', 
                         semester_id=topic.subject.semester.id,
                         subject_id=topic.subject.id, 
                         topic_id=topic_id)

        correct_count = 0
        results = []
        
        # First pass - minimal processing
        for i, question in enumerate(questions, start=1):
            user_answer = user_answers.get(str(i), "Not answered")
            is_correct = user_answer == question['answer']
            if is_correct:
                correct_count += 1

            results.append({
                "question": question['question'],
                "selected": user_answer,
                "correct": question['answer'],
                "is_correct": is_correct,
                "feedback": "Generating explanation...",  # Placeholder
                "q_index": i
            })

        # Calculate score
        total = len(questions)
        score = round((correct_count / total) * 100, 2) if total else 0

        # Store results
        past_results = request.session.get('past_results', [])
        past_results.append((correct_count, total - correct_count))
        request.session['past_results'] = past_results[-5:]
        request.session.modified = True

        # Generate performance graph
        performance_graph = generate_performance_graph(past_results)

        return render(request, 'mcq_app/quiz_results.html', {
            'topic': topic,
            'score': score,
            'results': results,
            'total': total,
            'correct_count': correct_count,
            'performance_graph': performance_graph,
            'initial_load': True
        })

    except Exception as e:
        logger.error(f"Quiz results error: {e}")
        messages.error(request, "An error occurred while processing your results.")
        return redirect('mcq_app:home')

@login_required
def generate_explanation(request):
    """Handle explanation generation requests"""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            question = data.get('question')
            correct = data.get('correct')
            selected = data.get('selected')
            topic = data.get('topic')
            subject = data.get('subject')
            
            prompt = f"""Explain this {subject} question:
            Q: {question}
            Correct: {correct}
            Student answered: {selected}
            
            Provide a focused 2-3 sentence explanation."""
            
            time.sleep(1.5)  # Rate limiting
            response = model.generate_content(prompt)
            
            return JsonResponse({
                'success': True,
                'explanation': response.text.strip()
            })
            
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            }, status=500)
    
    return JsonResponse({'error': 'Invalid request'}, status=400)

@login_required
def get_explanation(request, question_index=None):
    """
    Unified explanation endpoint that handles:
    - GET /get-explanation/<int:question_index>/
    - POST /generate-explanation/
    """
    try:
        if request.method == 'POST':
            # Handle POST request (from generate-explanation)
            data = json.loads(request.body)
            question = data.get('question')
            correct = data.get('correct')
            selected = data.get('selected')
            topic = data.get('topic', '')
            subject = data.get('subject', '')
        else:
            # Handle GET request (from get-explanation)
            questions = request.session.get('generated_questions', [])
            user_answers = request.session.get('quiz_answers', {})
            
            if 0 <= question_index < len(questions):
                question = questions[question_index]
                question_text = question['question']
                correct = question['answer']
                selected = user_answers.get(str(question_index+1), "Not answered")
                topic = ''
                subject = ''
            else:
                return JsonResponse({'success': False, 'error': 'Invalid question index'})

        prompt = f"""Explain this {subject} question:
        Q: {question_text if request.method == 'GET' else question}
        Correct: {correct}
        Student answered: {selected}

        Provide a focused 2-3 sentence explanation."""

        time.sleep(2)  # Rate limiting
        response = model.generate_content(prompt)
        
        return JsonResponse({
            'success': True,
            'explanation': response.text.strip()
        })

    except Exception as e:
        logger.error(f"Explanation error: {e}")
        return JsonResponse({
            'success': False,
            'error': str(e)
        }, status=500)


# ---------- Score Submission ----------

@login_required
def submit_quiz(request):
    if request.method == 'POST':
        user_answers = request.session.get('quiz_answers', {})
        questions = request.session.get('generated_questions', [])

        correct_count = sum(1 for i, q in enumerate(questions, start=1) if q['answer'] == user_answers.get(str(i), ""))
        total_questions = len(questions)
        score = correct_count

        feedback = save_score(request.user, score, total_questions)

        return render(request, 'mcq_app/quiz_results.html', {
            'score': score,
            'total': total_questions,
            'feedback': feedback
        })


# ---------- Debug URL Resolver ----------

def debug_urls(request):
    try:
        url = reverse('mcq_app:quiz_start', kwargs={'topic_id': 1})
        return HttpResponse(f"URL found: {url}")
    except Exception as e:
        return HttpResponse(f"Error: {str(e)}", status=400)
