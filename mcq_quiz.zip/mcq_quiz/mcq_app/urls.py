from django.urls import path
from . import views

app_name = 'mcq_app'

urlpatterns = [
    # Basic Navigation
    path('', views.home, name='home'),
    path('semesters/', views.semester_list, name='semester_list'),
    path('semester/<int:semester_id>/', views.semester_subjects, name='semester_subjects'),
    path('semester/<int:semester_id>/subject/<int:subject_id>/', views.subject_topics, name='subject_topics'),
    
    # Quiz Flow
    path('semester/<int:semester_id>/subject/<int:subject_id>/topic/<int:topic_id>/generate/', 
         views.generate_quiz, name='generate_quiz'),
    path('quiz/start/<int:topic_id>/', views.quiz_start, name='quiz_start'),
    path('quiz/<int:topic_id>/<int:question_num>/', views.quiz_question, name='quiz_question'),
    path('save-answer/', views.save_answer, name='save_answer'),
    path('quiz/<int:topic_id>/results/', views.quiz_results, name='quiz_results'),
    
    # Explanation Services
    path('generate-explanation/', views.generate_explanation, name='generate_explanation'),
    path('get-explanation/<int:question_index>/', views.get_explanation, name='get_explanation'),
    
    # User Progress
    path('submit-quiz/', views.submit_quiz, name='submit_quiz'),
    
    # Debugging (remove in production)
    path('debug-urls/', views.debug_urls, name='debug_urls'),
]