# mcq_app/management/commands/import_data.py
import json
from django.core.management.base import BaseCommand
from mcq_app.models import Semester, Subject, Topic

class Command(BaseCommand):
    help = 'Import academic structure from JSON'

    def add_arguments(self, parser):
        parser.add_argument('file_path', type=str, help='Path to JSON file')

    def handle(self, *args, **options):
        with open(options['file_path']) as f:
            data = json.load(f)
        
        for sem_num, subjects in data.items():
            semester, _ = Semester.objects.update_or_create(
                number=int(sem_num),
                defaults={
                    'name': f"Semester {sem_num}",
                    'description': f"Courses for semester {sem_num}"
                }
            )
            
            self.stdout.write(f"\nSemester {sem_num}:")
            
            for subject_name, topics in subjects.items():
                subject, _ = Subject.objects.update_or_create(
                    name=subject_name,
                    semester=semester,
                    defaults={'description': f"{subject_name} course"}
                )
                
                self.stdout.write(f"  {subject_name}:")
                
                for topic_name, topic_desc in topics:
                    topic, _ = Topic.objects.update_or_create(
                        name=topic_name,
                        subject=subject,
                        defaults={'description': topic_desc}
                    )
                    self.stdout.write(f"    - {topic_name}")
        
        self.stdout.write(self.style.SUCCESS('\nData import complete!'))