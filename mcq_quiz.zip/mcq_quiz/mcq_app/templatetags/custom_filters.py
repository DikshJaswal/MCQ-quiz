from django import template

register = template.Library()

@register.filter
def to_letter(value):
    return chr(64 + int(value))  # Converts 1→A, 2→B, etc.