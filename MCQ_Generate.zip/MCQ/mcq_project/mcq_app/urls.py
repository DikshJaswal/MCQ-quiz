from django.urls import path
from . import views

app_name = 'mcq_app'  # This is important for namespacing

urlpatterns = [
    path('', views.generate_quiz, name='generate_quiz'),
    path('quiz/<int:question_num>/', views.quiz, name='quiz'),  # This line was missing
    path('save-answer/', views.save_answer, name='save_answer'),
    path('submit/', views.submit_quiz, name='submit_quiz'),
]