from django.shortcuts import render, redirect
from django.http import JsonResponse
import google.generativeai as genai
from .models import QuizQuestion

# Configure Gemini AI
genai.configure(api_key="AIzaSyD94tk0A5c81p2ZiuTAiLLoFJzbHTiOLYI")
model = genai.GenerativeModel("gemini-1.5-pro")

def generate_quiz(request):
    if request.method == 'POST':
        # Clear existing questions
        QuizQuestion.objects.all().delete()
        
        # Generate questions using Gemini AI
        prompt = """
        Generate 10 multiple-choice questions about data structures with the following format for each question:
        
        Question: [question text]
        A) [option 1]
        B) [option 2]
        C) [option 3]
        D) [option 4]
        Correct Answer: [letter only]
        Explanation: [detailed explanation]
        
        Separate each question with "---"
        """
        
        response = model.generate_content(prompt)
        questions_text = response.text.split('---')
        
        # Parse and save questions
        for q in questions_text:
            if not q.strip():
                continue
                
            lines = [line.strip() for line in q.split('\n') if line.strip()]
            question_text = lines[0].replace('Question: ', '')
            options = [
                lines[1][3:],  # Remove "A) "
                lines[2][3:],  # Remove "B) "
                lines[3][3:],  # Remove "C) "
                lines[4][3:],  # Remove "D) "
            ]
            correct_answer = ord(lines[5][-1].upper()) - ord('A') + 1
            explanation = lines[6].replace('Explanation: ', '')
            
            QuizQuestion.objects.create(
                question_text=question_text,
                option1=options[0],
                option2=options[1],
                option3=options[2],
                option4=options[3],
                correct_option=correct_answer,
                explanation=explanation
            )
        
        return redirect('mcq_app:quiz', question_num=1)
    
    return render(request, 'mcq_app/generate.html')

def quiz(request, question_num):
    questions = QuizQuestion.objects.all().order_by('id')
    total_questions = questions.count()
    
    if question_num < 1 or question_num > total_questions:
        return redirect('quiz', question_num=1)
    
    question = questions[question_num - 1]
    
 # Debug output
    print("Current session answers:", request.session.get('user_answers', {}))

    # Get user's selected answer from session
    user_answers = request.session.get('user_answers', {})
    selected_option = user_answers.get(str(question.id), None)
    
    context = {
        'question': question,
        'question_num': question_num,
        'total_questions': total_questions,
        'selected_option': selected_option,
    }
    
    return render(request, 'mcq_app/quiz.html', context)

def save_answer(request):
    if request.method == 'POST':
        question_id = request.POST.get('question_id')
        selected_option = request.POST.get('selected_option')
        
        # Initialize session if not exists
        if 'user_answers' not in request.session:
            request.session['user_answers'] = {}
            
        # Save answer with question ID as string key
        request.session['user_answers'][str(question_id)] = selected_option
        request.session.modified = True  # Mark session as modified
        
        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'error'}, status=400)

def submit_quiz(request):
    questions = QuizQuestion.objects.all().order_by('id')
    user_answers = request.session.get('user_answers', {})
    
    score = 0
    results = []
    
    for question in questions:
        # Get user answer and convert to string for comparison
        user_answer = user_answers.get(str(question.id))
        is_correct = str(user_answer) == str(question.correct_option)
        
        if is_correct:
            score += 1
        
        results.append({
            'question': question.question_text,
            'user_answer': user_answer if user_answer else "Not answered",
            'correct_answer': question.correct_option,
            'explanation': question.explanation,
            'is_correct': is_correct,
        })
    
    percentage = (score / questions.count()) * 100 if questions.count() > 0 else 0
    
    context = {
        'score': score,
        'total': questions.count(),
        'percentage': percentage,
        'results': results,
    }
    
    return render(request, 'mcq_app/results.html', context)