# mcq_app/views.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required

def home(request):
    return render(request, 'mcq_app/home.html')

@login_required
def quiz(request, semester_name):  # Changed from semester_quiz to quiz
    # Your quiz view logic here
    return render(request, 'mcq_app/quiz.html', {'semester_name': semester_name})

@login_required
def semester_quiz(request, semester_num):
    # Your logic to get questions for the semester
    context = {
        'semester': semester_num,
        # Add other context data
    }
    return render(request, 'mcq_app/quiz.html', context)