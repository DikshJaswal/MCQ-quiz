from django.urls import path
from . import views  # This imports views from mcq_app, not accounts

urlpatterns = [
    path('', views.home, name='home'),  # This comes from mcq_app.views
    path('quiz/<str:semester_name>/', views.quiz, name='quiz'),
    path('semester/<int:semester_num>/', views.semester_quiz, name='semester_quiz'),
    # Remove the accounts include from here
]