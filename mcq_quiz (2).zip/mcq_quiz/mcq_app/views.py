import base64
import random
import logging
from io import BytesIO

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.urls import reverse

import google.generativeai as genai
import matplotlib.pyplot as plt

from .models import Semester, Subject, Topic, QuizQuestion, QuizAttempt, save_score
from .utils import generate_questions

import os
genai.configure(api_key='AIzaSyCB77gRvvBoT05NFWRRRBs2jMNGuyk_dp8')
model = genai.GenerativeModel("gemini-1.5-pro")

logger = logging.getLogger(__name__)


# ---------- Basic Views ----------

def home(request):
    return render(request, 'mcq_app/home.html')


@login_required
def semester_list(request):
    semesters = Semester.objects.all().order_by('number')
    return render(request, 'mcq_app/semester_list.html', {'semesters': semesters})


@login_required
def semester_subjects(request, semester_id):
    semester = get_object_or_404(Semester, pk=semester_id)
    subjects = Subject.objects.filter(semester=semester)
    return render(request, 'mcq_app/semester_subjects.html', {
        'semester_id': semester_id,
        'subjects': subjects
    })


@login_required
def subject_topics(request, semester_id, subject_id):
    subject = get_object_or_404(Subject, pk=subject_id, semester=semester_id)
    topics = Topic.objects.filter(subject=subject)
    return render(request, 'mcq_app/subject_topics.html', {
        'semester_id': semester_id,
        'subject_id': subject_id,
        'subject': subject,
        'topics': topics
    })


# ---------- Quiz Generation ----------

@login_required
def generate_quiz(request, semester_id, subject_id, topic_id):
    topic = get_object_or_404(Topic, pk=topic_id, subject_id=subject_id)

    if request.method == 'POST':
        questions = generate_questions(topic.name, topic.subject.name)
        if questions:
            request.session['generated_questions'] = questions
            request.session['quiz_answers'] = {}  # reset answers
            request.session.modified = True
            messages.success(request, "Quiz questions generated successfully!")
            return redirect('mcq_app:quiz_start', topic_id=topic.id)
        else:
            messages.error(request, "Failed to generate quiz questions. Please try again.")

    return render(request, 'mcq_app/generate.html', {'topic': topic})


# ---------- Quiz Flow ----------

@login_required
def quiz_start(request, topic_id):
    topic = get_object_or_404(Topic, id=topic_id)
    questions = request.session.get('generated_questions', [])

    if not questions:
        messages.error(request, "No questions available. Please generate quiz first.")
        return redirect('mcq_app:generate_quiz', semester_id=topic.subject.semester.id, subject_id=topic.subject.id, topic_id=topic_id)

    if request.method == "POST":
        answers = {str(i): request.POST.get(f'answer_{i}', None) for i in range(1, len(questions) + 1)}
        request.session['quiz_answers'] = answers
        request.session.modified = True
        return redirect('mcq_app:quiz_results', topic_id=topic_id)

    return render(request, 'mcq_app/quiz_start.html', {
        'topic': topic,
        'questions': questions,
        'question': questions[0],
        'question_num': 1,
        'total': len(questions),
        'progress_percentage': 0,
    })


@login_required
def quiz_question(request, topic_id, question_num):
    questions = request.session.get('generated_questions', [])
    total = len(questions)

    if not questions or question_num < 1 or question_num > total:
        return redirect('mcq_app:quiz_start', topic_id=topic_id)

    question = questions[question_num - 1]
    selected = request.session.get('quiz_answers', {}).get(str(question_num))

    return render(request, 'mcq_app/quiz_question.html', {
        'topic': get_object_or_404(Topic, id=topic_id),
        'question': question,
        'question_num': question_num,
        'total': total,
        'progress_percentage': (question_num / total) * 100,
        'selected_option': selected
    })


@login_required
def save_answer(request):
    if request.method == 'POST':
        question_id = request.POST.get('question_id')
        selected_option = request.POST.get('answer')

        request.session.setdefault('quiz_answers', {})
        request.session['quiz_answers'][question_id] = selected_option
        request.session.modified = True

        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'error'}, status=400)


# ---------- Quiz Results ----------

def generate_performance_graph(past_results):
    labels = [f"Q{i+1}" for i in range(len(past_results))]
    correct = [res[0] for res in past_results]
    wrong = [res[1] for res in past_results]

    plt.figure(figsize=(6, 4))
    plt.plot(labels, correct, marker='o', label='Correct', color='green')
    plt.plot(labels, wrong, marker='o', label='Wrong', color='red')
    plt.title('Quiz Performance Over Time')
    plt.xlabel('Attempt')
    plt.ylabel('Number of Questions')
    plt.legend()
    plt.tight_layout()

    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    graph_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    return graph_base64


@login_required
def quiz_results(request, topic_id):
    topic = get_object_or_404(Topic, id=topic_id)
    questions = request.session.get('generated_questions', [])
    user_answers = request.session.get('quiz_answers', {})

    if not questions or not user_answers:
        messages.error(request, "Quiz data missing.")
        return redirect('mcq_app:generate_quiz', semester_id=topic.subject.semester.id, subject_id=topic.subject.id, topic_id=topic_id)

    correct_count = 0
    results = []

    for i, question in enumerate(questions, start=1):
     user_answer = user_answers.get(str(i), "Not answered")
    is_correct = user_answer == question['answer']
    if is_correct:
        correct_count += 1

    prompt = (
        f"You are an intelligent tutor. A student just answered a quiz question on the topic '{topic.name}' "
        f"in the subject '{topic.subject.name}'.\n\n"
        f"Question: {question['question']}\n"
        f"Correct Answer: {question['answer']}\n"
        f"Student's Answer: {user_answer}\n\n"
        f"Explain in detail whether the student's answer is correct or incorrect, and provide a natural-language explanation "
        f"of the concept being tested. Don't mention that you're an AI. Keep it encouraging and educational."
    )

    try:
        feedback_response = model.generate_content(prompt)
        feedback_text = feedback_response.text.strip()
    except Exception as e:
        logger.error(f"Gemini feedback error: {e}")
        feedback_text = "Explanation not available at the moment."

    results.append({
        "question": question['question'],
        "selected": user_answer,
        "correct": question['answer'],
        "is_correct": is_correct,
        "feedback": feedback_text
    })


    total = len(questions)
    wrong_count = total - correct_count
    score = round((correct_count / total) * 100, 2) if total else 0

    past_results = request.session.get('past_results', [])
    past_results.append((correct_count, wrong_count))
    request.session['past_results'] = past_results[-5:]  # limit to last 5 attempts

    performance_graph = generate_performance_graph(past_results)

    return render(request, 'mcq_app/quiz_results.html', {
        'topic': topic,
        'score': score,
        'results': results,
        'total': total,
        'correct_count': correct_count,
        'performance_graph': performance_graph
    })


# ---------- Score Submission ----------

@login_required
def submit_quiz(request):
    if request.method == 'POST':
        user_answers = request.session.get('quiz_answers', {})
        questions = request.session.get('generated_questions', [])

        correct_count = sum(1 for i, q in enumerate(questions, start=1) if q['answer'] == user_answers.get(str(i), ""))
        total_questions = len(questions)
        score = correct_count

        feedback = save_score(request.user, score, total_questions)

        return render(request, 'mcq_app/quiz_results.html', {
            'score': score,
            'total': total_questions,
            'feedback': feedback
        })


# ---------- Debug URL Resolver ----------

def debug_urls(request):
    try:
        url = reverse('mcq_app:quiz_start', kwargs={'topic_id': 1})
        return HttpResponse(f"URL found: {url}")
    except Exception as e:
        return HttpResponse(f"Error: {str(e)}", status=400)
