import re

def parse_question(text):
    """Parses a question string into structured data."""
    match = re.search(r"Question:\s*(.*?)\nA\)\s*(.*?)\nB\)\s*(.*?)\nC\)\s*(.*?)\nD\)\s*(.*?)\nCorrect Answer:\s*(\w)\nExplanation:\s*(.*)", text, re.DOTALL)
    if match:
        return {
            "question": match.group(1),
            "options": [match.group(2), match.group(3), match.group(4), match.group(5)],
            "correct_option": match.group(6),
            "explanation": match.group(7),
        }
    return None

import google.generativeai as genai
import json

def generate_questions(topic_name, subject_name):
    prompt = f"""
    Generate 10 multiple-choice questions about {topic_name} in {subject_name}.
    Each question should have four options, with one correct answer.
    Format:
    [
        {{"question": "What is 2+2?", "options": ["3", "4", "5", "6"], "answer": "4"}},
        ...
    ]
    """
    try:
        model = genai.GenerativeModel("gemini-1.5-pro")
        response = model.generate_content(prompt)

        if not response or not hasattr(response, 'text') or not response.text.strip():
            print("❌ Gemini API returned an empty response!")
            return []

        # The response might be wrapped in a code block, remove that before parsing
        response_text = response.text.strip().replace("```json\n", "").replace("\n```", "")
        
        # Parse the raw response into a list of questions
        try:
            questions = json.loads(response_text)
            return questions
        except json.JSONDecodeError:
            print("❌ Failed to parse the response into JSON!")
            return []
        
    except Exception as e:
        print(f"❌ Error fetching questions: {e}")
        return []
