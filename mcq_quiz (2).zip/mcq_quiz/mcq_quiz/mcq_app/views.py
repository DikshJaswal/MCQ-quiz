from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from .models import Semester, Subject, Topic, QuizQuestion, QuizAttempt
from django.urls import reverse

def home(request):
    return render(request, 'mcq_app/home.html')

@login_required
def semester_list(request):
    semesters = Semester.objects.all().order_by('number')
    return render(request, 'mcq_app/semester_list.html', {'semesters': semesters})

from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404
from .models import Semester, Subject

@login_required
def semester_subjects(request, semester_id):
    semester = get_object_or_404(Semester, pk=semester_id)
    subjects = Subject.objects.filter(semester=semester)

    print("Subjects for Semester:", semester_id, list(subjects))  # Debugging   

    return render(request, 'mcq_app/semester_subjects.html', {
        'semester_id': semester_id,
        'subjects': subjects
    })

@login_required
def subject_topics(request, semester_id, subject_id):
    subject = get_object_or_404(Subject, pk=subject_id, semester=semester_id)
    topics = Topic.objects.filter(subject=subject)

    print("Topics for Subject:", subject_id, list(topics))  # Debugging  

    return render(request, 'mcq_app/subject_topics.html', {
        'semester_id': semester_id,
        'subject_id': subject_id,
        'subject': subject,
        'topics': topics
    })

import random
import logging
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib import messages
from django.contrib.auth.decorators import login_required
import google.generativeai as genai  # Ensure proper import of Gemini API
from django.http import JsonResponse
from .utils import generate_questions  # Adjust path if needed

# Set up logging
logger = logging.getLogger(__name__)

# Configure Gemini AI
genai.configure(api_key="AIzaSyBxW_hBQP-7dRZK00tFDRbTZtoZxWxeT70")  # Replace with your actual API key
model = genai.GenerativeModel("gemini-1.5-pro")  # Ensure consistency in model name

# Generate questions view
@login_required
def generate_quiz(request, semester_id, subject_id, topic_id):
    topic = get_object_or_404(Topic, pk=topic_id, subject_id=subject_id)
    
    # POST request for generating quiz questions
    if request.method == 'POST':
        print("📢 POST request received! Generating questions...")
        
        # Get the subject name and topic name
        subject_name = topic.subject.name
        topic_name = topic.name
        
        # Pass both topic_name and subject_name to the generate_questions function
        questions = generate_questions(topic_name, subject_name)
        print("📢 Generated questions:", questions)

        if questions:
            request.session['generated_questions'] = questions
            request.session.modified = True
            messages.success(request, "Quiz questions generated successfully!")
            return redirect('mcq_app:quiz_start', topic_id=topic.id)
        else:
            messages.error(request, "Failed to generate quiz questions. Please try again.")

    # Render the quiz generation page
    return render(request, 'mcq_app/generate.html', {'topic': topic})


# Quiz start view
from .models import Topic  # Ensure you have the Topic model imported
from .utils import generate_questions  # Assuming generate_questions is a function that gets the questions

@login_required
def quiz_start(request, topic_id):
    topic = get_object_or_404(Topic, id=topic_id)
    questions = request.session.get('generated_questions', [])

    if not questions:
        messages.error(request, "No questions available. Please try again.")
        return redirect('mcq_app:generate_quiz', semester_id=topic.subject.semester.id, subject_id=topic.subject.id, topic_id=topic_id)

    if request.method == "POST":
        # Save user answers in session
        answers = {}
        for i, question in enumerate(questions, start=1):
            answers[str(i)] = request.POST.get(f'answer_{i}', None)

        request.session['quiz_answers'] = answers
        request.session.modified = True

        return redirect('mcq_app:quiz_results', topic_id=topic_id) # Redirect to results

    return render(request, 'mcq_app/quiz_start.html', {
        'topic': topic,
        'questions': questions,
        'question': questions[0],
        'question_num': 1,
        'total': len(questions),
        'progress_percentage': 0,
    })



# Quiz question view
@login_required
def quiz_question(request, topic_id, question_num):
    questions = request.session.get('generated_questions', [])
    total = len(questions)
    
    if not questions or question_num < 1 or question_num > total:
        return redirect('mcq_app:quiz_start', topic_id=topic_id)
    
    question = questions[question_num - 1]
    selected = request.session.get('quiz_answers', {}).get(str(question_num))
    
    return render(request, 'quiz_question.html', {
        'topic': get_object_or_404(Topic, id=topic_id),
        'question': question,
        'question_num': question_num,
        'total': len(questions),
        'progress_percentage': (question_num / len(questions)) * 100,
        'selected_option': request.session.get('quiz_answers', {}).get(str(question_num))
    })
# Save answer view (AJAX)
@login_required
def save_answer(request):
    if request.method == 'POST':
        question_id = request.POST.get('question_id')
        selected_option = request.POST.get('answer')
        
        if 'quiz_answers' not in request.session:
            request.session['quiz_answers'] = {}
            
        request.session['quiz_answers'][question_id] = selected_option
        request.session.modified = True
        return JsonResponse({'status': 'success'})
    
    return JsonResponse({'status': 'error'}, status=400)

# Quiz results view
@login_required
def quiz_results(request, topic_id):
    topic = get_object_or_404(Topic, id=topic_id)
    questions = request.session.get('generated_questions', [])
    user_answers = request.session.get('quiz_answers', {})

    correct_count = 0
    results = []

    for i, question in enumerate(questions, start=1):
        correct = question['answer'] == user_answers.get(str(i), "")
        if correct:
            correct_count += 1
        results.append({
            "question": question['question'],
            "selected": user_answers.get(str(i), "Not answered"),
            "correct": question['answer'],
            "is_correct": correct
        })

    score = round((correct_count / len(questions)) * 100, 2) if questions else 0

    return render(request, 'mcq_app/quiz_results.html', {
        'topic': topic,
        'score': score,
        'results': results,
        'total': len(questions),
        'correct_count': correct_count
    })



# Debugging helper view (checking URLs)
from django.http import HttpResponse
def debug_urls(request):
    from django.urls import reverse
    try:
        url = reverse('mcq_app:quiz_start', kwargs={'topic_id': 1})
        return HttpResponse(f"URL found: {url}")
    except Exception as e:
        return HttpResponse(f"Error: {str(e)}", status=400)
