from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.core.exceptions import ValidationError
from .models import User
from django.contrib.auth.forms import AuthenticationForm

class LoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Username'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password'}))

    error_messages = {
        'invalid_login': "Username or password is wrong.",
        'inactive': "This account is inactive.",
    }

class SignupForm(UserCreationForm):
    email = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Email'}))

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Username'}),
            'password1': forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Password'}),
            'password2': forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Confirm Password'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get('password1')
        password2 = cleaned_data.get('password2')
        email = cleaned_data.get('email')

        # Check for password mismatch
        if password1 and password2 and password1 != password2:
            raise ValidationError("Passwords do not match.")

        # Check for password length
        if password1 and len(password1) < 8:
            raise ValidationError("This password is too short. It must contain at least 8 characters.")

        # Check for common password
        common_passwords = ['password', '12345678', 'qwerty', 'admin']  # Add more common passwords if needed
        if password1 and password1.lower() in common_passwords:
            raise ValidationError("This password is too common.")

        # Check for numeric password
        if password1 and password1.isdigit():
            raise ValidationError("This password is entirely numeric.")

        # Check for similarity to email
        if password1 and email and email.lower() in password1.lower():
            raise ValidationError("The password is too similar to the email.")

        return cleaned_data