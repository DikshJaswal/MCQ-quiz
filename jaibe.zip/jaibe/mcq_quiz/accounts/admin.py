# accounts/admin.py
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User  # Changed from CustomUser to User

# Unregister any existing User model if needed
# admin.site.unregister(User)  # Uncomment if needed

admin.site.register(User, UserAdmin)