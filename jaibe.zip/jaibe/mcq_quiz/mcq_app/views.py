# mcq_app/views.py
from django.shortcuts import render
from django.contrib.auth.decorators import login_required

def home(request):
    return render(request, 'mcq_app/home.html')

@login_required
def quiz(request, semester_name):  # Changed from semester_quiz to quiz
    # Your quiz view logic here
    return render(request, 'mcq_app/quiz.html', {'semester_name': semester_name})

@login_required
def semester_quiz(request, semester_num):
    # Your logic to get questions for the semester
    context = {
        'semester': semester_num,
        # Add other context data
    }
    return render(request, 'mcq_app/quiz.html', context)

#for subjects
from django.shortcuts import render, get_object_or_404
from .models import Subject

@login_required
def semester_subjects(request, semester_num):
    subjects = Subject.objects.filter(semester=semester_num)
    semester_name = get_semester_name(semester_num)  # Helper function
    return render(request, 'mcq_app/subjects.html', {
        'subjects': subjects,
        'semester_num': semester_num,
        'semester_name': semester_name
    })

def get_semester_name(num):
    # Map semester numbers to names
    names = {
        1: "1st Year - Semester 1",
        2: "1st Year - Semester 2",
        3: "2nd Year - Semester 3",
        4: "2nd Year - Semester 4",
        5: "3rd Year - Semester 5",
        6: "3rd Year - Semester 6",
        7: "4th Year - Semester 7",
        8: "4th Year - Semester 8"
    }
    return names.get(num, f"Semester {num}")

def subject_quiz(request, semester_num, subject_id):
    subject = get_object_or_404(Subject, id=subject_id, semester=semester_num)
    return render(request, 'mcq_app/quiz.html', {
        'subject': subject,
        'semester_num': semester_num
    })

from django.shortcuts import render, get_object_or_404
from .models import Subject

@login_required
def semester_subjects(request, semester_num):
    # Map semester numbers to their names
    semester_names = {
        1: "First Semester",
        2: "Second Semester",
        3: "Third Semester",
        4: "Fourth Semester",
        5: "Fifth Semester",
        6: "Sixth Semester",
        7: "Seventh Semester",
        8: "Eighth Semester",
    }
    
    # Define subjects for all 8 semesters
    semester_subjects = {
        # Semester 1
        1: [
            {'id': 1, 'name': 'Mathematics-I', 'description': 'Differential and Integral Calculus'},
            {'id': 2, 'name': 'Physics', 'description': 'Mechanics, Thermodynamics, Waves'},
            {'id': 3, 'name': 'Programming Fundamentals', 'description': 'C Programming Basics'},
        ],
        
        # Semester 2
        2: [
            {'id': 1, 'name': 'Mathematics-II', 'description': 'Multivariable Calculus and ODEs'},
            {'id': 2, 'name': 'Chemistry', 'description': 'Atomic Structure and Chemical Bonding'},
            {'id': 3, 'name': 'Object Oriented Programming', 'description': 'OOP Concepts with C++'},
        ],
        
        # Semester 3
        3: [
            {'id': 1, 'name': 'Data Structures', 'description': 'Arrays, Linked Lists, Trees'},
            {'id': 2, 'name': 'Discrete Mathematics', 'description': 'Set Theory and Graph Theory'},
            {'id': 3, 'name': 'Digital Logic', 'description': 'Boolean Algebra and Circuits'},
        ],
        
        # Semester 4
        4: [
            {'id': 1, 'name': 'Algorithms', 'description': 'Divide & Conquer, Greedy Algorithms'},
            {'id': 2, 'name': 'Computer Organization', 'description': 'Processor Architecture'},
            {'id': 3, 'name': 'Operating Systems', 'description': 'Process and Memory Management'},
        ],
        
        # Semester 5
        5: [
            {'id': 1, 'name': 'Database Systems', 'description': 'ER Modeling and SQL'},
            {'id': 2, 'name': 'Computer Networks', 'description': 'Network Layers and Protocols'},
            {'id': 3, 'name': 'Theory of Computation', 'description': 'Finite Automata and Grammars'},
        ],
        
        # Semester 6
        6: [
            {'id': 1, 'name': 'Compiler Design', 'description': 'Lexical and Syntax Analysis'},
            {'id': 2, 'name': 'Software Engineering', 'description': 'SDLC and Testing Methodologies'},
            {'id': 3, 'name': 'Web Technologies', 'description': 'HTML, CSS, JavaScript'},
        ],
        
        # Semester 7
        7: [
            {'id': 1, 'name': 'Artificial Intelligence', 'description': 'Search Algorithms and Knowledge Representation'},
            {'id': 2, 'name': 'Machine Learning', 'description': 'Regression and Classification'},
            {'id': 3, 'name': 'Cloud Computing', 'description': 'Virtualization and Cloud Models'},
        ],
        
        # Semester 8
        8: [
            {'id': 1, 'name': 'Big Data Analytics', 'description': 'Hadoop Ecosystem and NoSQL'},
            {'id': 2, 'name': 'Cyber Security', 'description': 'Cryptography and Network Security'},
            {'id': 3, 'name': 'Project Work', 'description': 'Final Year Project Implementation'},
        ]
    }
    
    context = {
        'semester_num': semester_num,
        'semester_name': semester_names.get(semester_num, f"Semester {semester_num}"),
        'subjects': semester_subjects.get(semester_num, []),
    }
    return render(request, 'subjects/semester_subjects.html', context)

@login_required
def subject_topics(request, semester_num, subject_id):
    # Map subjects to their names and descriptions
    subject_data = {
        1: {
            'name': 'Mathematics-I' if semester_num == 1 else 
                   'Mathematics-II' if semester_num == 2 else
                   'Data Structures' if semester_num == 3 else
                   'Algorithms' if semester_num == 4 else
                   'Database Systems' if semester_num == 5 else
                   'Compiler Design' if semester_num == 6 else
                   'Artificial Intelligence' if semester_num == 7 else
                   'Big Data Analytics',
            'description': 'Mathematics fundamentals' if semester_num in [1, 2] else
                         'Core computer science concepts' if semester_num in [3, 4] else
                         'Advanced computing topics'
        },
        2: {
            'name': 'Physics' if semester_num == 1 else
                   'Chemistry' if semester_num == 2 else
                   'Discrete Mathematics' if semester_num == 3 else
                   'Computer Organization' if semester_num == 4 else
                   'Computer Networks' if semester_num == 5 else
                   'Software Engineering' if semester_num == 6 else
                   'Machine Learning' if semester_num == 7 else
                   'Cyber Security',
            'description': 'Basic science principles' if semester_num in [1, 2] else
                         'Theoretical foundations' if semester_num == 3 else
                         'Hardware and systems' if semester_num == 4 else
                         'Networking concepts' if semester_num == 5 else
                         'Software development methodologies' if semester_num == 6 else
                         'Advanced computing topics'
        },
        3: {
            'name': 'Programming Fundamentals' if semester_num == 1 else
                   'Object Oriented Programming' if semester_num == 2 else
                   'Digital Logic' if semester_num == 3 else
                   'Operating Systems' if semester_num == 4 else
                   'Theory of Computation' if semester_num == 5 else
                   'Web Technologies' if semester_num == 6 else
                   'Cloud Computing' if semester_num == 7 else
                   'Project Work',
            'description': 'Programming basics' if semester_num in [1, 2] else
                         'Hardware fundamentals' if semester_num == 3 else
                         'System software' if semester_num == 4 else
                         'Theoretical CS' if semester_num == 5 else
                         'Web development' if semester_num == 6 else
                         'Distributed systems' if semester_num == 7 else
                         'Final year project'
        }
    }
    
    subject_info = subject_data.get(subject_id, {'name': f'Subject {subject_id}', 'description': 'No description available'})
    
    context = {
        'semester_num': semester_num,
        'subject_id': subject_id,
        'subject_name': subject_info['name'],
        'subject_description': subject_info['description'],
    }
    return render(request, 'topics/subject_topics.html', context)

@login_required
def semester_list(request):
    semesters = [
        {'number': 1, 'name': 'First Semester'},
        {'number': 2, 'name': 'Second Semester'},
        {'number': 3, 'name': 'Third Semester'},
        {'number': 4, 'name': 'Fourth Semester'},
        {'number': 5, 'name': 'Fifth Semester'},
        {'number': 6, 'name': 'Sixth Semester'},
        {'number': 7, 'name': 'Seventh Semester'},
        {'number': 8, 'name': 'Eighth Semester'},
    ]
    return render(request, 'subjects/semester_list.html', {'semesters': semesters})

from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
import google.generativeai as genai
from .models import Subject, QuizQuestion
import random
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# Configure Gemini AI
genai.configure(api_key="AIzaSyD94tk0A5c81p2ZiuTAiLLoFJzbHTiOLYI")
model = genai.GenerativeModel("gemini-1.5-pro")

# ... (keep all your existing views as they are) ...

@login_required
def generate_quiz(request, semester_num, subject_id):
    subject = get_object_or_404(Subject, id=subject_id, semester=semester_num)
    
    # Get topic from GET parameter or POST data
    topic = request.GET.get('topic', request.POST.get('topic', subject.name))
    
    if request.method == 'POST':
        try:
            # Delete existing questions for this subject and topic
            QuizQuestion.objects.filter(subject=subject).delete()
            
            created_count = 0
            attempts = 0
            max_attempts = 3
            
            prompt_variations = [
                "Focus on real-world applications",
                "Include questions with diagrams in the explanation",
                "Use programming examples in questions",
                "Include time complexity analysis",
                "Compare with other concepts"
            ]
            
            while created_count < 15 and attempts < max_attempts:
                attempts += 1
                remaining = 15 - created_count
                variation = random.choice(prompt_variations)
                
                prompt = f"""
                Generate EXACTLY {remaining} NEW multiple-choice questions about {topic}.
                {f'Focus on {"hard" if created_count >= 10 else "medium" if created_count >=5 else "easy"} level questions.' if attempts > 1 else ''}
                
                IMPORTANT:
                - These must be DIFFERENT questions from previous generations
                - {variation}
                - Avoid repeating similar question formats
                - Current generation attempt: {attempts}
                
                STRICT FORMAT for EACH QUESTION:
                Question: [unique question text]
                A) [option 1]
                B) [option 2]
                C) [option 3]
                D) [option 4]
                Correct Answer: [A/B/C/D]
                Explanation: [detailed explanation]
                Difficulty: [easy/medium/hard]
                
                SEPARATE QUESTIONS WITH: "====="
                """
                
                response = model.generate_content(prompt)
                questions_text = [q.strip() for q in response.text.split("=====") if q.strip()]
                
                for q in questions_text:
                    if created_count >= 15:
                        break
                        
                    try:
                        lines = [line.strip() for line in q.split('\n') if line.strip()]
                        
                        if len(lines) < 8:  # Now expecting 8 lines (added difficulty)
                            continue
                            
                        question_data = {
                            'question_text': '',
                            'options': [],
                            'correct_answer': None,
                            'explanation': '',
                            'difficulty': 'medium'
                        }
                        
                        for line in lines:
                            if line.startswith('Question:'):
                                question_data['question_text'] = line[9:].strip()
                            elif line.startswith(('A)', 'B)', 'C)', 'D)')):
                                question_data['options'].append(line[3:].strip())
                            elif line.startswith('Correct Answer:'):
                                question_data['correct_answer'] = ord(line[-1].upper()) - ord('A') + 1
                            elif line.startswith('Explanation:'):
                                question_data['explanation'] = line[12:].strip()
                            elif line.startswith('Difficulty:'):
                                question_data['difficulty'] = line[11:].strip().lower()
                        
                        if (len(question_data['options']) == 4 and 
                            question_data['correct_answer'] and
                            question_data['question_text']):
                            
                            QuizQuestion.objects.create(
                                subject=subject,
                                question_text=question_data['question_text'],
                                option1=question_data['options'][0],
                                option2=question_data['options'][1],
                                option3=question_data['options'][2],
                                option4=question_data['options'][3],
                                correct_option=question_data['correct_answer'],
                                explanation=question_data['explanation'],
                                difficulty=question_data['difficulty']
                            )
                            created_count += 1
                            
                    except Exception as e:
                        print(f"Skipping question due to error: {e}")
                        continue
            
            if created_count < 15:
                messages.warning(request, f"Generated {created_count}/15 questions")
            else:
                messages.success(request, f"New {topic} quiz generated successfully!")
            
            return redirect('mcq_app:subject_quiz', semester_num=semester_num, subject_id=subject_id)
        
        except Exception as e:
            messages.error(request, f"Quiz generation failed: {str(e)}")
            return redirect('mcq_app:subject_topics', semester_num=semester_num, subject_id=subject_id)
    
    # Pass the topic to the template
    return render(request, 'mcq_app/generate.html', {
        'subject': subject,
        'topic': request.GET.get('topic', None)
    })

@login_required
def save_answer(request, semester_num, subject_id):
    if request.method == 'POST':
        question_id = request.POST.get('question_id')
        selected_option = request.POST.get('selected_option')
        
        if 'quiz_session' in request.session:
            request.session['quiz_session']['answers'][str(question_id)] = selected_option
            request.session['quiz_session']['current_question'] += 1
            request.session.modified = True
        
        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'error'}, status=400)

@login_required
def subject_quiz(request, semester_num, subject_id):
    subject = get_object_or_404(Subject, id=subject_id, semester=semester_num)
    questions = QuizQuestion.objects.filter(subject=subject).order_by('?')  # Random order
    
    # Initialize session for quiz tracking
    if 'quiz_session' not in request.session:
        request.session['quiz_session'] = {
            'subject_id': subject_id,
            'answers': {},
            'current_question': 1,
            'total_questions': questions.count()
        }
        request.session.modified = True
    
    question_num = request.session['quiz_session']['current_question']
    try:
        question = questions[question_num - 1] if questions.count() >= question_num else None
    except IndexError:
        question = None
    
    if not question:
        return redirect('mcq_app:submit_quiz', semester_num=semester_num, subject_id=subject_id)
    
    context = {
        'semester_num': semester_num,
        'subject': subject,
        'question': question,
        'question_num': question_num,
        'total_questions': questions.count(),
        'selected_option': request.session['quiz_session']['answers'].get(str(question.id))
    }
    return render(request, 'subjects/quiz.html', context)

@login_required
def submit_quiz(request, semester_num, subject_id):
    subject = get_object_or_404(Subject, id=subject_id, semester=semester_num)
    questions = QuizQuestion.objects.filter(subject=subject)
    
    if 'quiz_session' not in request.session:
        return redirect('mcq_app:subject_quiz', semester_num=semester_num, subject_id=subject_id)
    
    user_answers = request.session['quiz_session'].get('answers', {})
    score = 0
    results = []
    
    for question in questions:
        user_answer = user_answers.get(str(question.id))
        is_correct = str(user_answer) == str(question.correct_option) if user_answer else False
        
        if is_correct:
            score += 1
        
        results.append({
            'question': question.question_text,
            'user_answer': question.get_correct_option_display() if user_answer is None else 
                          ['A', 'B', 'C', 'D'][int(user_answer)-1] if user_answer else 'Not answered',
            'correct_answer': question.get_correct_option_display(),
            'explanation': question.explanation,
            'is_correct': is_correct
        })
    
    # Clear quiz session
    if 'quiz_session' in request.session:
        del request.session['quiz_session']
    
    context = {
        'semester_num': semester_num,
        'subject': subject,
        'score': score,
        'total': questions.count(),
        'percentage': (score / questions.count()) * 100 if questions.count() > 0 else 0,
        'results': results
    }
    return render(request, 'subjects/quiz_results.html', context)