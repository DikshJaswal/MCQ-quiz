from django.contrib import admin
from .models import Subject  # Import your Subject model

@admin.register(Subject)  # Register the model
class SubjectAdmin(admin.ModelAdmin):
    list_display = ('name', 'semester', 'created_at')  # Columns in admin list view
    list_filter = ('semester',)  # Filter sidebar
    search_fields = ('name', 'description')  # Search box functionality