from django.db import models

class Subject(models.Model):
    SEMESTER_CHOICES = [
        (1, "1st Year - Semester 1"),
        (2, "1st Year - Semester 2"),
        (3, "2nd Year - Semester 3"),
        (4, "2nd Year - Semester 4"),
        (5, "3rd Year - Semester 5"),
        (6, "3rd Year - Semester 6"),
        (7, "4th Year - Semester 7"),
        (8, "4th Year - Semester 8"),
    ]
    
    name = models.CharField(max_length=100)
    semester = models.IntegerField(choices=SEMESTER_CHOICES)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.get_semester_display()} - {self.name}"

class QuizQuestion(models.Model):
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    question_text = models.TextField()
    option1 = models.CharField(max_length=200)
    option2 = models.CharField(max_length=200)
    option3 = models.CharField(max_length=200)
    option4 = models.CharField(max_length=200)
    correct_option = models.IntegerField(choices=[(1, 'A'), (2, 'B'), (3, 'C'), (4, 'D')])
    explanation = models.TextField()
    difficulty = models.CharField(max_length=10, choices=[
        ('easy', 'Easy'), 
        ('medium', 'Medium'), 
        ('hard', 'Hard')
    ], default='medium')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.subject.name} - {self.question_text[:50]}..."