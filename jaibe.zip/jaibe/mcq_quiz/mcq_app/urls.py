from django.urls import path
from . import views

app_name = 'mcq_app'  # This sets the namespace

urlpatterns = [
    path('', views.home, name='home'),  # This is your home URL
    path('semester/<int:semester_num>/', views.semester_subjects, name='semester_subjects'),
    path('semester/<int:semester_num>/subject/<int:subject_id>/', views.subject_topics, name='subject_topics'),
    path('semester/<int:semester_num>/subject/<int:subject_id>/quiz/', views.subject_quiz, name='subject_quiz'),
    path('semester/<int:semester_num>/subject/<int:subject_id>/generate/', views.generate_quiz, name='generate_quiz'),
    path('semester/<int:semester_num>/subject/<int:subject_id>/save-answer/', views.save_answer, name='save_answer'),
    path('semester/<int:semester_num>/subject/<int:subject_id>/submit/', views.submit_quiz, name='submit_quiz'),
    path('semesters/', views.semester_list, name='semester_list'),
]